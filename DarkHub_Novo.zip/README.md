# DarkHub — site dark premium + Cloudflare Turnstile

Projeto pronto para personalização e hospedagem em um servidor Node.js.

## 1. Requisitos

- Node.js 18+
- Uma conta Cloudflare
- Um domínio (para produção)
- Um widget Cloudflare Turnstile

O Turnstile precisa de uma `sitekey` no navegador e uma `secret key` no servidor. A secret nunca deve ser colocada no JavaScript público.

## 2. Configurar o Cloudflare Turnstile

No painel da Cloudflare, crie um widget Turnstile para seu domínio e copie:

- Site Key
- Secret Key

Para produção, restrinja o widget ao seu domínio.

## 3. Configurar o projeto

Copie `.env.example` para `.env` e preencha:

TURNSTILE_SITE_KEY=...
TURNSTILE_SECRET=...
SESSION_SECRET=uma-chave-grande-e-aleatoria
ADMIN_KEY=uma-chave-grande-e-aleatoria

## 4. Rodar

```bash
npm install
npm start
```

Abra:

http://localhost:3000

## 5. Adicionar produtos

Edite:

`data/products.json`

Exemplo:

```json
{
  "id": "meu-produto",
  "name": "Meu Produto",
  "description": "Descrição",
  "category": "Scripts",
  "version": "1.0",
  "downloads": 0,
  "downloadUrl": "https://seu-link-de-download.com/arquivo"
}
```

## 6. Segurança

A rota `/api/download/:id` exige uma sessão verificada. O servidor valida o token do Turnstile diretamente com a API Siteverify da Cloudflare antes de criar essa sessão.

Não coloque a `TURNSTILE_SECRET` no frontend.

## 7. Personalização

O visual principal está em:

`public/style.css`

O nome e textos estão em:

`public/index.html`

Você pode trocar `DarkHub` pelo nome da sua marca.

## 8. Admin API opcional

Se `ADMIN_KEY` estiver configurada:

GET `/api/admin/products`

PUT `/api/admin/products`

Envie o header:

`x-admin-key: SUA_ADMIN_KEY`

Use isso apenas em ambiente controlado. Para um painel administrativo completo, recomendo adicionar autenticação e banco de dados.
