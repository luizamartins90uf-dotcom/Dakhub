let products = [];

const $ = (s) => document.querySelector(s);

async function api(url, options = {}) {
  const r = await fetch(url, options);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || "request_failed");
  return data;
}

function renderProducts(list) {
  const grid = $("#products-grid");
  if (!list.length) {
    grid.innerHTML = '<div class="card"><h4>Nenhum produto encontrado</h4><p>Tente outro termo de busca.</p></div>';
    return;
  }

  grid.innerHTML = list.map(p => `
    <article class="card">
      <div class="card-icon">${(p.name || "P").charAt(0).toUpperCase()}</div>
      <h4>${escapeHtml(p.name)}</h4>
      <p>${escapeHtml(p.description || "")}</p>
      <div class="meta">
        <span class="tag">${escapeHtml(p.category || "Produto")}</span>
        <span class="tag">v${escapeHtml(p.version || "1.0.0")}</span>
        <span class="tag">${Number(p.downloads || 0)} downloads</span>
      </div>
      <a class="download" href="/api/download/${encodeURIComponent(p.id)}">Acessar / baixar</a>
    </article>
  `).join("");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

async function loadProducts() {
  products = await api("/api/products");
  renderProducts(products);
}

async function initTurnstile() {
  const config = await api("/api/config");
  if (!config.siteKey || config.siteKey.includes("COLOQUE_")) {
    $("#gate-status").textContent = "Configure TURNSTILE_SITE_KEY no .env";
    return;
  }

  const wait = setInterval(() => {
    if (window.turnstile) {
      clearInterval(wait);
      window.turnstile.render("#turnstile", {
        sitekey: config.siteKey,
        theme: "dark",
        appearance: "always",
        callback: async (token) => {
          $("#gate-status").textContent = "Validando...";
          try {
            const form = new URLSearchParams();
            form.set("cf-turnstile-response", token);
            await api("/api/verify", {
              method: "POST",
              headers: {"Content-Type": "application/x-www-form-urlencoded"},
              body: form.toString()
            });
            $("#verification").classList.add("hidden");
            $("#app").classList.remove("hidden");
            $("#gate-status").textContent = "Verificado!";
            await loadProducts();
          } catch (e) {
            $("#gate-status").textContent = "A verificação falhou. Tente novamente.";
          }
        },
        "error-callback": () => {
          $("#gate-status").textContent = "Erro na verificação. Recarregue a página.";
        },
        "expired-callback": () => {
          $("#gate-status").textContent = "A verificação expirou. Faça novamente.";
        }
      });
    }
  }, 100);
}

$("#search").addEventListener("input", (e) => {
  const q = e.target.value.toLowerCase().trim();
  renderProducts(products.filter(p =>
    `${p.name} ${p.description} ${p.category}`.toLowerCase().includes(q)
  ));
});

$("#logout").addEventListener("click", async () => {
  await api("/api/logout", {method:"POST"});
  location.reload();
});

$("#year").textContent = new Date().getFullYear();
initTurnstile().catch(() => {
  $("#gate-status").textContent = "Não foi possível carregar a configuração.";
});
