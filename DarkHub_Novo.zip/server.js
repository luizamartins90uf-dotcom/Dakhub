const express = require("express");
const cookieSession = require("cookie-session");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const SITE_KEY = process.env.TURNSTILE_SITE_KEY || "";
const TURNSTILE_SECRET = process.env.TURNSTILE_SECRET || "";
const SESSION_SECRET = process.env.SESSION_SECRET || "change-me-in-production";
const ADMIN_KEY = process.env.ADMIN_KEY || "";

const productsPath = path.join(__dirname, "data", "products.json");

app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(cookieSession({
  name: "darkhub_session",
  keys: [SESSION_SECRET],
  httpOnly: true,
  sameSite: "lax",
  secure: process.env.NODE_ENV === "production",
  maxAge: 1000 * 60 * 60 * 24
}));

app.use(express.static(path.join(__dirname, "public")));

function readProducts() {
  try {
    return JSON.parse(fs.readFileSync(productsPath, "utf8"));
  } catch {
    return [];
  }
}

function writeProducts(products) {
  fs.writeFileSync(productsPath, JSON.stringify(products, null, 2));
}

function requireVerification(req, res, next) {
  if (req.session && req.session.verified) return next();
  return res.status(403).json({ ok: false, error: "verification_required" });
}

app.get("/api/config", (req, res) => {
  res.json({ siteKey: SITE_KEY });
});

app.get("/api/products", requireVerification, (req, res) => {
  res.json(readProducts());
});

app.post("/api/verify", async (req, res) => {
  const token = req.body["cf-turnstile-response"];
  if (!token) {
    return res.status(400).json({ ok: false, error: "missing_token" });
  }
  if (!TURNSTILE_SECRET) {
    return res.status(500).json({ ok: false, error: "turnstile_not_configured" });
  }

  try {
    const ip = req.headers["cf-connecting-ip"] || req.socket.remoteAddress || "";
    const response = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        secret: TURNSTILE_SECRET,
        response: token,
        remoteip: ip
      })
    });

    const result = await response.json();

    if (!result.success) {
      return res.status(403).json({
        ok: false,
        error: "verification_failed",
        codes: result["error-codes"] || []
      });
    }

    req.session.verified = true;
    return res.json({ ok: true });
  } catch (error) {
    console.error("Turnstile validation error:", error);
    return res.status(502).json({ ok: false, error: "verification_service_error" });
  }
});

app.post("/api/logout", (req, res) => {
  req.session = null;
  res.json({ ok: true });
});

app.get("/api/download/:id", requireVerification, (req, res) => {
  const products = readProducts();
  const product = products.find(p => p.id === req.params.id);
  if (!product || !product.downloadUrl) {
    return res.status(404).send("Produto não encontrado.");
  }

  product.downloads = Number(product.downloads || 0) + 1;
  writeProducts(products);

  return res.redirect(product.downloadUrl);
});

// Simple optional admin API. Keep ADMIN_KEY private.
function requireAdmin(req, res, next) {
  const key = req.get("x-admin-key") || req.query.key;
  if (!ADMIN_KEY || key !== ADMIN_KEY) {
    return res.status(401).json({ ok: false, error: "unauthorized" });
  }
  next();
}

app.get("/api/admin/products", requireAdmin, (req, res) => {
  res.json(readProducts());
});

app.put("/api/admin/products", requireAdmin, (req, res) => {
  if (!Array.isArray(req.body)) {
    return res.status(400).json({ ok: false, error: "body_must_be_array" });
  }
  writeProducts(req.body);
  res.json({ ok: true, products: req.body });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`DarkHub running on http://localhost:${PORT}`);
});
